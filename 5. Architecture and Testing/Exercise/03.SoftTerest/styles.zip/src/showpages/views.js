const section = document.getElementById('homePage');


export function showHome(x) {
    x.showSection(section);
}